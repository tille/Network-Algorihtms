package advertisement;

/**
 *
 * @authores Carlos Adrian Tobon Perez - Paola Andrea Vallejo Correa
 */

public class Main { 
    
    public Main() {
    }
    
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SenderInterface().setVisible(true);
            }
        });
    }
}